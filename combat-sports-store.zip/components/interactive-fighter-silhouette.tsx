"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface BodyPart {
  id: string
  name: string
  products: Array<{ name: string; price: string; category: string }>
  path: string
}

const bodyParts: BodyPart[] = [
  {
    id: "head",
    name: "Cabeza",
    products: [
      { name: "Casco Profesional", price: "$89.99", category: "headgear" },
      { name: "Bucal Premium", price: "$24.99", category: "mouthguard" },
      { name: "Headgear Elite", price: "$129.99", category: "headgear" },
    ],
    // Cabeza más realista con forma ovalada y cuello
    path: "M130 25 C145 20, 160 25, 165 40 C168 50, 165 60, 160 65 C155 68, 150 70, 145 72 L145 85 C145 88, 142 90, 140 90 L120 90 C118 90, 115 88, 115 85 L115 72 C110 70, 105 68, 100 65 C95 60, 92 50, 95 40 C100 25, 115 20, 130 25 Z",
  },
  {
    id: "torso",
    name: "Torso",
    products: [
      { name: "Peto de Competición", price: "$149.99", category: "chest-protector" },
      { name: "Protector de Pecho", price: "$79.99", category: "chest-guard" },
      { name: "Uniformes", price: "$59.99", category: "uniforms" },
    ],
    // Torso con forma de V invertida, hombros anchos y cintura estrecha
    path: "M115 90 C105 92, 95 95, 88 100 C82 105, 78 115, 75 125 L70 160 C68 175, 70 190, 75 200 C80 208, 88 212, 95 215 L95 230 C95 235, 100 238, 105 238 L155 238 C160 238, 165 235, 165 230 L165 215 C172 212, 180 208, 185 200 C190 190, 192 175, 190 160 L185 125 C182 115, 178 105, 172 100 C165 95, 155 92, 145 90 Z",
  },
  {
    id: "left-arm",
    name: "Manos",
    products: [
      { name: "Guantes de Boxeo Pro", price: "$119.99", category: "gloves" },
      { name: "Vendas Mexicanas", price: "$14.99", category: "wraps" },
      { name: "Guantes MMA", price: "$89.99", category: "mma-gloves" },
    ],
    // Brazo izquierdo en guardia alta con forma muscular
    path: "M88 100 C80 98, 72 100, 65 105 L50 120 C45 125, 42 132, 40 140 L35 155 C33 162, 35 170, 40 175 C45 180, 52 182, 58 180 L65 178 C68 177, 70 175, 72 172 L78 160 C80 155, 82 150, 83 145 L88 125 C90 118, 90 110, 88 100 Z",
  },
  {
    id: "right-arm",
    name: "Manos",
    products: [
      { name: "Guantes de Boxeo Pro", price: "$119.99", category: "gloves" },
      { name: "Vendas Mexicanas", price: "$14.99", category: "wraps" },
      { name: "Guantes MMA", price: "$89.99", category: "mma-gloves" },
    ],
    // Brazo derecho en guardia baja con forma muscular
    path: "M172 100 C180 98, 188 100, 195 105 L210 120 C215 125, 218 132, 220 140 L225 155 C227 162, 225 170, 220 175 C215 180, 208 182, 202 180 L195 178 C192 177, 190 175, 188 172 L182 160 C180 155, 178 150, 177 145 L172 125 C170 118, 170 110, 172 100 Z",
  },
  {
    id: "left-leg",
    name: "Piernas",
    products: [
      { name: "Espinilleras Venom", price: "$69.99", category: "shin-guards" },
      { name: "Protector de Muslo", price: "$49.99", category: "thigh-protector" },
      { name: "Zapatillas de Boxeo", price: "$99.99", category: "shoes" },
    ],
    // Pierna izquierda con muslo, pantorrilla y pie definidos
    path: "M105 238 C102 240, 100 245, 98 250 L92 280 C90 295, 88 310, 87 325 L85 350 C84 360, 85 370, 87 380 L88 395 C88 400, 90 405, 93 408 L95 415 C96 418, 98 420, 101 420 L110 420 C113 420, 115 418, 116 415 L118 408 C121 405, 123 400, 123 395 L124 380 C126 370, 127 360, 126 350 L124 325 C123 310, 121 295, 118 280 L112 250 C110 245, 108 240, 105 238 Z",
  },
  {
    id: "right-leg",
    name: "Piernas",
    products: [
      { name: "Espinilleras Venom", price: "$69.99", category: "shin-guards" },
      { name: "Protector de Muslo", price: "$49.99", category: "thigh-protector" },
      { name: "Zapatillas de Boxeo", price: "$99.99", category: "shoes" },
    ],
    // Pierna derecha con muslo, pantorrilla y pie definidos
    path: "M155 238 C158 240, 160 245, 162 250 L168 280 C170 295, 172 310, 173 325 L175 350 C176 360, 175 370, 173 380 L172 395 C172 400, 170 405, 167 408 L165 415 C164 418, 162 420, 159 420 L150 420 C147 420, 145 418, 144 415 L142 408 C139 405, 137 400, 137 395 L136 380 C134 370, 133 360, 134 350 L136 325 C137 310, 139 295, 142 280 L148 250 C150 245, 152 240, 155 238 Z",
  },
  {
    id: "groin",
    name: "Ingle",
    products: [
      { name: "Coquilla Profesional", price: "$34.99", category: "groin-protector" },
      { name: "Protector Inguinal", price: "$44.99", category: "groin-guard" },
    ],
    // Área inguinal más anatómica
    path: "M115 215 C112 220, 110 225, 110 230 C110 233, 112 236, 115 238 L145 238 C148 236, 150 233, 150 230 C150 225, 148 220, 145 215 L130 215 Z",
  },
]

export function InteractiveFighterSilhouette() {
  const [hoveredPart, setHoveredPart] = useState<string | null>(null)
  const [selectedPart, setSelectedPart] = useState<string | null>(null)

  const handlePartClick = (partId: string) => {
    setSelectedPart(partId)
  }

  const hoveredBodyPart = bodyParts.find((part) => part.id === hoveredPart)
  const selectedBodyPart = bodyParts.find((part) => part.id === selectedPart)

  return (
    <section className="py-20 bg-gradient-to-br from-zinc-950 via-zinc-900 to-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(217,119,6,0.1),transparent_50%)]" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 mb-4 tracking-tight">
            ENCUENTRA TU EQUIPO POR ZONA
          </h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Selecciona la parte del cuerpo para ver el equipo de protección específico
          </p>
        </div>

        <div className="flex flex-col items-center justify-center gap-12">
          {/* Silueta del luchador - centrada */}
          <div className="flex justify-center relative">
            <motion.svg
              width="260"
              height="440"
              viewBox="0 0 260 440"
              className="drop-shadow-2xl"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
            >
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="4" result="coloredBlur" />
                  <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
                <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3f3f46" />
                  <stop offset="50%" stopColor="#27272a" />
                  <stop offset="100%" stopColor="#18181b" />
                </linearGradient>
              </defs>

              {bodyParts.map((part) => (
                <motion.path
                  key={part.id}
                  d={part.path}
                  fill={hoveredPart === part.id || selectedPart === part.id ? "#d97706" : "url(#bodyGradient)"}
                  stroke={hoveredPart === part.id || selectedPart === part.id ? "#f59e0b" : "#52525b"}
                  strokeWidth={hoveredPart === part.id || selectedPart === part.id ? "3" : "2"}
                  className="cursor-pointer transition-all duration-300"
                  filter={hoveredPart === part.id || selectedPart === part.id ? "url(#glow)" : "none"}
                  onMouseEnter={() => setHoveredPart(part.id)}
                  onMouseLeave={() => setHoveredPart(null)}
                  onClick={() => handlePartClick(part.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  style={{
                    filter:
                      hoveredPart === part.id || selectedPart === part.id
                        ? "drop-shadow(0 0 10px #d97706) drop-shadow(0 0 20px #f59e0b)"
                        : "none",
                  }}
                />
              ))}

              <motion.ellipse
                cx="58"
                cy="175"
                rx="12"
                ry="15"
                fill="#f59e0b"
                className="opacity-90"
                animate={{ scale: [1, 1.1, 1], opacity: [0.9, 1, 0.9] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
              />
              <motion.ellipse
                cx="202"
                cy="175"
                rx="12"
                ry="15"
                fill="#d97706"
                className="opacity-90"
                animate={{ scale: [1, 1.1, 1], opacity: [0.9, 1, 0.9] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: 1 }}
              />
            </motion.svg>

            {/* Tooltip mejorado */}
            {hoveredPart && hoveredBodyPart && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute -top-16 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-4 py-2 rounded-lg text-sm font-bold whitespace-nowrap z-10 shadow-xl"
              >
                <div className="text-center">
                  <div className="font-bold">{hoveredBodyPart.name}</div>
                  <div className="text-xs opacity-90">Click para ver productos</div>
                </div>
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-amber-600"></div>
              </motion.div>
            )}
          </div>

          {/* Panel de productos - centrado */}
          <div className="w-full max-w-6xl">
            {selectedBodyPart ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <h3 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-orange-500 mb-6">
                  Productos para {selectedBodyPart.name}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {selectedBodyPart.products.map((product, index) => (
                    <motion.div
                      key={product.name}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-zinc-900 rounded-xl overflow-hidden shadow-xl border border-zinc-800 hover:border-amber-600 transition-all duration-300 hover:shadow-2xl hover:shadow-amber-600/20"
                    >
                      <div className="aspect-square bg-zinc-800 flex items-center justify-center">
                        <div className="text-6xl opacity-50">🥊</div>
                      </div>
                      <div className="p-4">
                        <h4 className="font-bold text-white text-lg mb-2">{product.name}</h4>
                        <p className="text-2xl font-bold text-amber-500 mb-4">{product.price}</p>
                        <Link href={`/productos/${product.category}`}>
                          <Button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300">
                            Ver Productos
                          </Button>
                        </Link>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-zinc-900 rounded-xl p-8 shadow-2xl text-center border border-zinc-800"
              >
                <div className="text-7xl mb-6">🥊</div>
                <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-orange-500 mb-4">
                  Explora por Zona Corporal
                </h3>
                <p className="text-zinc-400 text-lg">
                  Haz clic sobre la silueta del luchador para ver qué productos necesitas para cada parte del cuerpo.
                  Cada zona te mostrará el equipo específico de protección.
                </p>
              </motion.div>
            )}
          </div>
        </div>

        {/* Leyenda de colores */}
        <div className="mt-12 flex justify-center">
          <div className="bg-zinc-900 rounded-lg p-4 flex items-center space-x-6 shadow-xl border border-zinc-800">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-zinc-800 border border-zinc-700 rounded"></div>
              <span className="text-sm font-medium text-zinc-400">Normal</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-amber-600 rounded shadow-lg"></div>
              <span className="text-sm font-medium text-zinc-400">Hover/Seleccionado</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
