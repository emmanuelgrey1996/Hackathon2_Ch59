import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const sports = [
  {
    name: "BOXEO",
    description: "Guantes, vendas, bucales, conjuntos y zapatillas profesionales",
    image: "/professional-boxing-gloves-elite.jpg",
    products: ["Guantes", "Bucales", "Vendas", "Conjuntos", "Zapatillas"],
  },
  {
    name: "TAEKWONDO",
    description: "Doboks, protecciones, cinturones y equipo de competición",
    image: "/taekwondo-uniform-and-protective-gear.jpg",
    products: ["Doboks", "Protecciones", "Cinturones", "Petos", "Cascos"],
  },
  {
    name: "MMA",
    description: "Guantes MMA, shorts, rashguards y equipo de entrenamiento",
    image: "/mma-complete-gear-setup.jpg",
    products: ["Guantes MMA", "Shorts", "Rashguards", "Espinilleras", "Vendas"],
  },
  {
    name: "KARATE",
    description: "Karategis, cinturones, mitones y equipo de kumite",
    image: "/karate-gi-and-competition-equipment.jpg",
    products: ["Karategis", "Cinturones", "Mitones", "Protectores", "Cascos"],
  },
]

export function SportsCategories() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            DEPORTES DE <span className="elite-text">COMBATE</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Especialistas en equipamiento profesional para cada disciplina
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {sports.map((sport, index) => (
            <Card key={sport.name} className="sport-card-hover bg-card border-border overflow-hidden">
              <div className="relative h-64">
                <img src={sport.image || "/placeholder.svg"} alt={sport.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40" />
                <div className="absolute top-4 left-4">
                  <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                    DEPORTE ÉLITE
                  </span>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-2">{sport.name}</h3>
                <p className="text-muted-foreground mb-4">{sport.description}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {sport.products.map((product) => (
                    <span
                      key={product}
                      className="bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-sm"
                    >
                      {product}
                    </span>
                  ))}
                </div>
                <Button className="w-full">VER PRODUCTOS DE {sport.name}</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
