import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative hero-gradient py-24 md:py-32 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-30">
        <img
          src="/olympic-combat-sports-arena-intense.jpg"
          alt="Olympic Combat Sports Arena"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-balance">
            ENTRENA COMO UN <span className="elite-text">CAMPEÓN</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
            Equípate con el gear de élite que usan los profesionales. Boxeo, Taekwondo, MMA y Karate al más alto nivel.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6">
              EXPLORAR PRODUCTOS
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
              VER COLECCIÓN ÉLITE
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
