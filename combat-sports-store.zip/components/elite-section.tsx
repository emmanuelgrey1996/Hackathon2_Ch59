import { Button } from "@/components/ui/button"
import { Trophy, Shield, Star, Target } from "lucide-react"

const features = [
  {
    icon: Trophy,
    title: "CALIDAD PROFESIONAL",
    description: "Equipamiento usado por campeones mundiales y atletas de élite",
  },
  {
    icon: Shield,
    title: "GARANTÍA TOTAL",
    description: "Garantía de por vida en todos nuestros productos premium",
  },
  {
    icon: Star,
    title: "MATERIALES PREMIUM",
    description: "Solo los mejores materiales para máximo rendimiento y durabilidad",
  },
  {
    icon: Target,
    title: "PRECISIÓN TÉCNICA",
    description: "Diseñado específicamente para cada disciplina de combate",
  },
]

export function EliteSection() {
  return (
    <section className="py-20 bg-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            ¿POR QUÉ ELEGIR <span className="elite-text">ELITE COMBAT</span>?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Somos la marca de confianza de los atletas profesionales. Nuestro compromiso es llevarte al siguiente nivel.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div key={feature.title} className="text-center group">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm text-pretty">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-card border border-border rounded-lg p-8 md:p-12 text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-4">
            ÚNETE A LA <span className="elite-text">ÉLITE</span>
          </h3>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Más de 10,000 atletas profesionales confían en nosotros. Es tu momento de entrenar como un campeón.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6">
              COMPRAR AHORA
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
              CONTACTAR ASESOR
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
