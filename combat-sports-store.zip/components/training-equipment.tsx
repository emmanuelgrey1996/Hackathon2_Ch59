"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Star } from "lucide-react"
import Image from "next/image"

const trainingEquipment = [
  {
    id: 1,
    name: "Costal Profesional 150cm",
    category: "Costales",
    price: 189.99,
    rating: 4.9,
    image: "/professional-heavy-bag-150cm.jpg",
    description: "Costal de alta resistencia para entrenamiento intensivo",
  },
  {
    id: 2,
    name: "Pera de Velocidad Elite",
    category: "Peras",
    price: 79.99,
    rating: 4.8,
    image: "/speed-bag-elite.jpg",
    description: "Pera de velocidad para mejorar reflejos y coordinación",
  },
  {
    id: 3,
    name: "Gobernadora Ajustable Pro",
    category: "Gobernadoras",
    price: 249.99,
    rating: 5.0,
    image: "/adjustable-double-end-bag.jpg",
    description: "Gobernadora de doble extremo con altura ajustable",
  },
  {
    id: 4,
    name: "Jaula Octagonal MMA",
    category: "Jaulas",
    price: 4999.99,
    rating: 5.0,
    image: "/octagonal-mma-cage.jpg",
    description: "Jaula profesional octagonal para entrenamiento MMA",
  },
  {
    id: 5,
    name: "Dummy de Grappling",
    category: "Dummies",
    price: 299.99,
    rating: 4.7,
    image: "/grappling-dummy.jpg",
    description: "Muñeco de entrenamiento para técnicas de suelo",
  },
  {
    id: 6,
    name: "Ring de Boxeo Profesional",
    category: "Rings",
    price: 3499.99,
    rating: 5.0,
    image: "/professional-boxing-ring.jpg",
    description: "Ring completo con lona y cuerdas profesionales",
  },
  {
    id: 7,
    name: "Escudo de Golpeo Curvo",
    category: "Escudos",
    price: 129.99,
    rating: 4.8,
    image: "/curved-strike-shield.jpg",
    description: "Escudo ergonómico para entrenamiento de golpes",
  },
  {
    id: 8,
    name: "Manoplas de Enfoque",
    category: "Manoplas",
    price: 89.99,
    rating: 4.9,
    image: "/focus-mitts-pro.jpg",
    description: "Manoplas profesionales para trabajo de precisión",
  },
]

const categories = ["Todos", "Costales", "Peras", "Gobernadoras", "Jaulas", "Dummies", "Rings", "Escudos", "Manoplas"]

export function TrainingEquipment() {
  const [selectedCategory, setSelectedCategory] = useState("Todos")

  const filteredEquipment =
    selectedCategory === "Todos"
      ? trainingEquipment
      : trainingEquipment.filter((item) => item.category === selectedCategory)

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-background to-background/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-gradient-to-r from-amber-500 to-orange-600 text-white border-0 px-6 py-2 text-sm font-bold tracking-wider">
            EQUIPAMIENTO PROFESIONAL
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-600 bg-clip-text text-transparent">
            Material de Entrenamiento
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Equipa tu gimnasio con material de élite. Desde costales hasta jaulas profesionales.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className={`
                ${
                  selectedCategory === category
                    ? "bg-gradient-to-r from-amber-500 to-orange-600 text-white border-0"
                    : "border-amber-500/30 hover:border-amber-500 hover:bg-amber-500/10"
                }
                transition-all duration-300
              `}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Equipment Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredEquipment.map((item) => (
            <Card
              key={item.id}
              className="group overflow-hidden border-border/50 hover:border-amber-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/10 bg-card/50 backdrop-blur-sm"
            >
              <CardContent className="p-0">
                <div className="relative h-64 overflow-hidden bg-muted">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-black/70 text-amber-400 border-amber-500/50">{item.category}</Badge>
                  </div>
                </div>

                <div className="p-5">
                  <h3 className="font-bold text-lg mb-2 group-hover:text-amber-500 transition-colors">{item.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{item.description}</p>

                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(item.rating) ? "fill-amber-500 text-amber-500" : "text-muted"
                        }`}
                      />
                    ))}
                    <span className="text-sm text-muted-foreground ml-2">{item.rating}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                      ${item.price}
                    </span>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0"
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Agregar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
