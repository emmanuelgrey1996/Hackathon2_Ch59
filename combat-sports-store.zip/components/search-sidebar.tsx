"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Search, Filter, X, ChevronDown, ChevronUp } from "lucide-react"

interface SearchSidebarProps {
  isOpen: boolean
  onClose: () => void
}

function AnatomicalSilhouette() {
  const [hoveredPart, setHoveredPart] = useState<string | null>(null)

  const bodyParts = [
    { id: "head", name: "Cabeza", products: "Cascos, Bucales", color: "#ff6b35" },
    { id: "hands", name: "Manos", products: "Guantes, Vendas", color: "#f7931e" },
    { id: "torso", name: "Torso", products: "Petos, Camisetas", color: "#ffd23f" },
    { id: "legs", name: "Piernas", products: "Espinilleras, Shorts", color: "#06ffa5" },
    { id: "feet", name: "Pies", products: "Zapatillas, Tobilleras", color: "#4ecdc4" },
  ]

  const handlePartClick = (partId: string) => {
    console.log(`[v0] Navegando a productos de: ${partId}`)
    // Aquí se podría implementar la navegación real
  }

  return (
    <div className="relative bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl p-6 border border-amber-500/20 shadow-lg">
      <h3 className="text-center text-amber-400 font-bold text-sm mb-4 tracking-wider">SELECCIONA POR ZONA CORPORAL</h3>

      <div className="relative mx-auto w-40 h-56 bg-slate-800/50 rounded-lg p-4">
        <svg viewBox="0 0 100 150" className="w-full h-full drop-shadow-lg">
          {/* Cabeza */}
          <circle
            cx="50"
            cy="15"
            r="12"
            fill={hoveredPart === "head" ? "#ff6b35" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-orange-500 hover:stroke-orange-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("head")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("head")}
          />

          {/* Torso */}
          <rect
            x="35"
            y="25"
            width="30"
            height="40"
            rx="8"
            fill={hoveredPart === "torso" ? "#ffd23f" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-yellow-400 hover:stroke-yellow-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("torso")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("torso")}
          />

          {/* Brazos/Manos */}
          <rect
            x="18"
            y="30"
            width="14"
            height="28"
            rx="7"
            fill={hoveredPart === "hands" ? "#f7931e" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-orange-400 hover:stroke-orange-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("hands")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("hands")}
          />
          <rect
            x="68"
            y="30"
            width="14"
            height="28"
            rx="7"
            fill={hoveredPart === "hands" ? "#f7931e" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-orange-400 hover:stroke-orange-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("hands")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("hands")}
          />

          {/* Piernas */}
          <rect
            x="40"
            y="65"
            width="8"
            height="35"
            rx="4"
            fill={hoveredPart === "legs" ? "#06ffa5" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-emerald-400 hover:stroke-emerald-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("legs")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("legs")}
          />
          <rect
            x="52"
            y="65"
            width="8"
            height="35"
            rx="4"
            fill={hoveredPart === "legs" ? "#06ffa5" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-emerald-400 hover:stroke-emerald-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("legs")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("legs")}
          />

          {/* Pies */}
          <ellipse
            cx="44"
            cy="108"
            rx="10"
            ry="5"
            fill={hoveredPart === "feet" ? "#4ecdc4" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-teal-400 hover:stroke-teal-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("feet")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("feet")}
          />
          <ellipse
            cx="56"
            cy="108"
            rx="10"
            ry="5"
            fill={hoveredPart === "feet" ? "#4ecdc4" : "#475569"}
            stroke="#fbbf24"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:fill-teal-400 hover:stroke-teal-400 hover:drop-shadow-glow"
            onMouseEnter={() => setHoveredPart("feet")}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick("feet")}
          />
        </svg>

        {hoveredPart && (
          <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-amber-500 to-orange-500 text-black px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap border border-amber-400 shadow-lg animate-pulse">
            {bodyParts.find((part) => part.id === hoveredPart)?.products}
          </div>
        )}
      </div>

      <div className="mt-6 space-y-2">
        <p className="text-xs text-amber-400 font-semibold text-center mb-2">PASA EL CURSOR SOBRE CADA ZONA</p>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {bodyParts.map((part) => (
            <div key={part.id} className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: part.color }}></div>
              <span className="text-slate-300 font-medium">{part.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function SearchSidebar({ isOpen, onClose }: SearchSidebarProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [priceRange, setPriceRange] = useState([0, 500])
  const [expandedSections, setExpandedSections] = useState({
    anatomical: true,
    sports: true,
    categories: true,
    training: true,
    brands: false,
    price: true,
  })

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  const sports = [
    { id: "boxing", name: "Boxeo", count: 45, color: "#ef4444" },
    { id: "taekwondo", name: "Taekwondo", count: 32, color: "#3b82f6" },
    { id: "mma", name: "MMA", count: 58, color: "#f59e0b" },
    { id: "karate", name: "Karate", count: 28, color: "#10b981" },
  ]

  const categories = [
    { id: "gloves", name: "Guantes", count: 24, icon: "🥊" },
    { id: "protection", name: "Protección", count: 18, icon: "🛡️" },
    { id: "clothing", name: "Ropa", count: 35, icon: "👕" },
    { id: "shoes", name: "Calzado", count: 16, icon: "👟" },
    { id: "equipment", name: "Equipamiento", count: 22, icon: "⚡" },
    { id: "accessories", name: "Accesorios", count: 12, icon: "🎯" },
  ]

  const trainingEquipment = [
    { id: "bags", name: "Costales", count: 15, icon: "🥊" },
    { id: "pears", name: "Peras de Velocidad", count: 8, icon: "⚡" },
    { id: "governors", name: "Gobernadoras", count: 6, icon: "🎯" },
    { id: "cage", name: "Jaulas/Octágonos", count: 3, icon: "⬢" },
    { id: "mats", name: "Colchonetas", count: 12, icon: "📐" },
    { id: "rings", name: "Rings de Boxeo", count: 2, icon: "⭕" },
    { id: "dummies", name: "Muñecos de Entrenamiento", count: 7, icon: "🤖" },
    { id: "weights", name: "Pesas y Lastres", count: 18, icon: "🏋️" },
  ]

  const brands = [
    { id: "venum", name: "Venum", count: 28, color: "#fbbf24" },
    { id: "everlast", name: "Everlast", count: 22, color: "#ef4444" },
    { id: "hayabusa", name: "Hayabusa", count: 15, color: "#8b5cf6" },
    { id: "rdx", name: "RDX", count: 18, color: "#06b6d4" },
    { id: "title", name: "Title", count: 12, color: "#10b981" },
  ]

  return (
    <>
      {/* Overlay */}
      {isOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />}

      {/* Sidebar */}
      <div
        className={`
        fixed top-0 left-0 h-full w-80 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 border-r border-amber-500/30 z-50 transform transition-transform duration-300 ease-in-out overflow-y-auto
        ${isOpen ? "translate-x-0" : "-translate-x-full"}
        lg:relative lg:translate-x-0 lg:z-auto
      `}
        style={{ fontFamily: "Inter, system-ui, sans-serif" }}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-slate-900 to-slate-800 border-b border-amber-500/30 p-4 flex items-center justify-between backdrop-blur-sm">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-amber-400" />
            <h2 className="font-black text-lg text-amber-400 tracking-wider">FILTROS ELITE</h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="lg:hidden text-amber-400 hover:bg-amber-400/10"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="p-4 space-y-6">
          {/* Search */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-amber-400 tracking-widest">BUSCAR PRODUCTOS</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-amber-400" />
              <Input
                placeholder="Buscar equipamiento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-800/50 border-amber-500/30 focus:border-amber-400 text-white placeholder:text-slate-400 font-medium"
              />
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => toggleSection("anatomical")}
              className="flex items-center justify-between w-full text-left"
            >
              <span className="text-xs font-bold text-amber-400 tracking-widest">BÚSQUEDA ANATÓMICA</span>
              {expandedSections.anatomical ? (
                <ChevronUp className="h-4 w-4 text-amber-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-amber-400" />
              )}
            </button>
            {expandedSections.anatomical && <AnatomicalSilhouette />}
          </div>

          {/* Sports Filter */}
          <div className="space-y-3">
            <button
              onClick={() => toggleSection("sports")}
              className="flex items-center justify-between w-full text-left"
            >
              <span className="text-xs font-bold text-amber-400 tracking-widest">DEPORTES</span>
              {expandedSections.sports ? (
                <ChevronUp className="h-4 w-4 text-amber-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-amber-400" />
              )}
            </button>
            {expandedSections.sports && (
              <div className="space-y-2">
                {sports.map((sport) => (
                  <div
                    key={sport.id}
                    className="flex items-center justify-between group hover:bg-slate-800/30 p-2 rounded-lg transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox id={sport.id} className="border-amber-500/50 data-[state=checked]:bg-amber-500" />
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: sport.color }}></div>
                        <label
                          htmlFor={sport.id}
                          className="text-sm cursor-pointer text-white font-medium group-hover:text-amber-400 transition-colors"
                        >
                          {sport.name}
                        </label>
                      </div>
                    </div>
                    <span className="text-xs text-amber-400 font-bold">({sport.count})</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Categories Filter */}
          <div className="space-y-3">
            <button
              onClick={() => toggleSection("categories")}
              className="flex items-center justify-between w-full text-left"
            >
              <span className="text-xs font-bold text-amber-400 tracking-widest">CATEGORÍAS</span>
              {expandedSections.categories ? (
                <ChevronUp className="h-4 w-4 text-amber-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-amber-400" />
              )}
            </button>
            {expandedSections.categories && (
              <div className="space-y-2">
                {categories.map((category) => (
                  <div
                    key={category.id}
                    className="flex items-center justify-between group hover:bg-slate-800/30 p-2 rounded-lg transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox id={category.id} className="border-amber-500/50 data-[state=checked]:bg-amber-500" />
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">{category.icon}</span>
                        <label
                          htmlFor={category.id}
                          className="text-sm cursor-pointer text-white font-medium group-hover:text-amber-400 transition-colors"
                        >
                          {category.name}
                        </label>
                      </div>
                    </div>
                    <span className="text-xs text-amber-400 font-bold">({category.count})</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <button
              onClick={() => toggleSection("training")}
              className="flex items-center justify-between w-full text-left"
            >
              <span className="text-xs font-bold text-amber-400 tracking-widest">MATERIAL DE ENTRENAMIENTO</span>
              {expandedSections.training ? (
                <ChevronUp className="h-4 w-4 text-amber-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-amber-400" />
              )}
            </button>
            {expandedSections.training && (
              <div className="space-y-2">
                {trainingEquipment.map((equipment) => (
                  <div
                    key={equipment.id}
                    className="flex items-center justify-between group hover:bg-slate-800/30 p-2 rounded-lg transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox id={equipment.id} className="border-amber-500/50 data-[state=checked]:bg-amber-500" />
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">{equipment.icon}</span>
                        <label
                          htmlFor={equipment.id}
                          className="text-sm cursor-pointer text-white font-medium group-hover:text-amber-400 transition-colors"
                        >
                          {equipment.name}
                        </label>
                      </div>
                    </div>
                    <span className="text-xs text-amber-400 font-bold">({equipment.count})</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Price Range */}
          <div className="space-y-3">
            <button
              onClick={() => toggleSection("price")}
              className="flex items-center justify-between w-full text-left"
            >
              <span className="text-xs font-bold text-amber-400 tracking-widest">PRECIO</span>
              {expandedSections.price ? (
                <ChevronUp className="h-4 w-4 text-amber-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-amber-400" />
              )}
            </button>
            {expandedSections.price && (
              <div className="space-y-4 bg-slate-800/30 p-3 rounded-lg">
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={500}
                  step={10}
                  className="w-full [&_[role=slider]]:bg-amber-500 [&_[role=slider]]:border-amber-400"
                />
                <div className="flex items-center justify-between text-sm font-bold text-amber-400">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    type="number"
                    placeholder="Min"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([Number.parseInt(e.target.value) || 0, priceRange[1]])}
                    className="text-sm bg-slate-700 border-amber-500/30 text-white"
                  />
                  <Input
                    type="number"
                    placeholder="Max"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], Number.parseInt(e.target.value) || 500])}
                    className="text-sm bg-slate-700 border-amber-500/30 text-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Brands Filter */}
          <div className="space-y-3">
            <button
              onClick={() => toggleSection("brands")}
              className="flex items-center justify-between w-full text-left"
            >
              <span className="text-xs font-bold text-amber-400 tracking-widest">MARCAS</span>
              {expandedSections.brands ? (
                <ChevronUp className="h-4 w-4 text-amber-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-amber-400" />
              )}
            </button>
            {expandedSections.brands && (
              <div className="space-y-2">
                {brands.map((brand) => (
                  <div
                    key={brand.id}
                    className="flex items-center justify-between group hover:bg-slate-800/30 p-2 rounded-lg transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox id={brand.id} className="border-amber-500/50 data-[state=checked]:bg-amber-500" />
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: brand.color }}></div>
                        <label
                          htmlFor={brand.id}
                          className="text-sm cursor-pointer text-white font-medium group-hover:text-amber-400 transition-colors"
                        >
                          {brand.name}
                        </label>
                      </div>
                    </div>
                    <span className="text-xs text-amber-400 font-bold">({brand.count})</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-4 border-t border-amber-500/30">
            <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-black font-bold tracking-wide">
              APLICAR FILTROS
            </Button>
            <Button
              variant="outline"
              className="w-full bg-transparent border-amber-500/50 text-amber-400 hover:bg-amber-400/10 font-bold tracking-wide"
            >
              LIMPIAR TODO
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}
