import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Star, ShoppingCart } from "lucide-react"

const featuredProducts = [
  {
    name: "Guantes de Boxeo Pro Elite",
    price: "$189.99",
    originalPrice: "$249.99",
    rating: 5,
    reviews: 127,
    image: "/professional-boxing-gloves-black-and-gold.jpg",
    category: "BOXEO",
    badge: "BESTSELLER",
  },
  {
    name: "Dobok Taekwondo Competición",
    price: "$159.99",
    originalPrice: "$199.99",
    rating: 5,
    reviews: 89,
    image: "/white-taekwondo-uniform-professional.jpg",
    category: "TAEKWONDO",
    badge: "NUEVO",
  },
  {
    name: "Guantes MMA Elite Fighter",
    price: "$129.99",
    originalPrice: "$169.99",
    rating: 5,
    reviews: 203,
    image: "/mma-fighting-gloves-professional-black.jpg",
    category: "MMA",
    badge: "ÉLITE",
  },
  {
    name: "Karategi Kumite Pro",
    price: "$139.99",
    originalPrice: "$179.99",
    rating: 5,
    reviews: 156,
    image: "/white-karate-gi-competition-grade.jpg",
    category: "KARATE",
    badge: "PRO",
  },
]

export function FeaturedProducts() {
  return (
    <section className="py-20 bg-secondary/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            PRODUCTOS <span className="elite-text">DESTACADOS</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Los favoritos de los campeones. Calidad profesional garantizada.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product, index) => (
            <Card key={product.name} className="sport-card-hover bg-card border-border overflow-hidden">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span className="bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-bold">
                    {product.badge}
                  </span>
                </div>
                <div className="absolute top-3 right-3">
                  <span className="bg-secondary text-secondary-foreground px-2 py-1 rounded text-xs">
                    {product.category}
                  </span>
                </div>
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg mb-2 text-balance">{product.name}</h3>

                <div className="flex items-center mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${i < product.rating ? "fill-primary text-primary" : "text-muted-foreground"}`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground ml-2">({product.reviews})</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl font-bold text-primary">{product.price}</span>
                    <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                  </div>
                </div>

                <Button className="w-full" size="sm">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  AGREGAR AL CARRITO
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            VER TODOS LOS PRODUCTOS
          </Button>
        </div>
      </div>
    </section>
  )
}
