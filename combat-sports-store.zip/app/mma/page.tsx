import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"
import Image from "next/image"

export default function MMAPage() {
  const mmaProducts = [
    {
      id: 1,
      name: "Guantes de MMA 4oz",
      price: "$69.99",
      image: "/mma-gloves-and-fighting-gear.jpg",
      category: "Guantes",
    },
    {
      id: 2,
      name: "Shorts de MMA",
      price: "$59.99",
      image: "/mma-shorts-black.jpg",
      category: "Uniformes",
    },
    {
      id: 3,
      name: "Espinilleras MMA Venom",
      price: "$79.99",
      image: "/smooth-mma-shin-guards-venom-style.jpg",
      category: "Protección",
    },
    {
      id: 4,
      name: "Rashguard Compresión",
      price: "$49.99",
      image: "/training-shirt.jpg",
      category: "Uniformes",
    },
    {
      id: 5,
      name: "Vendas de Mano MMA",
      price: "$19.99",
      image: "/hand-wraps.jpg",
      category: "Protección",
    },
    {
      id: 6,
      name: "Protector Bucal",
      price: "$24.99",
      image: "/mouthguard.jpg",
      category: "Protección",
    },
    {
      id: 7,
      name: "Jaula Octagonal MMA",
      price: "$4999.99",
      image: "/octagonal-mma-cage.jpg",
      category: "Entrenamiento",
    },
    {
      id: 8,
      name: "Dummy de Grappling",
      price: "$299.99",
      image: "/grappling-dummy.jpg",
      category: "Entrenamiento",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center overflow-hidden">
        <Image src="/mma-gloves-and-fighting-gear.jpg" alt="MMA" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
        <div className="relative z-10 text-center px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 elite-text">MMA</h1>
          <p className="text-xl md:text-2xl text-zinc-300 max-w-2xl mx-auto">
            Equipo profesional para guerreros del octágono
          </p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Productos de MMA</h2>
          <p className="text-zinc-400">Equipo de élite para artes marciales mixtas</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {mmaProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-all duration-300"
            >
              <div className="relative h-64 overflow-hidden bg-zinc-900">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-bold">
                  {product.category}
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{product.name}</h3>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary">{product.price}</span>
                  <Button size="sm" className="gap-2">
                    <ShoppingCart className="h-4 w-4" />
                    Agregar
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  )
}
