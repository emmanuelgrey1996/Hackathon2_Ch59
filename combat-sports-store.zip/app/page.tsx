"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { SportsCategories } from "@/components/sports-categories"
import { FeaturedProducts } from "@/components/featured-products"
import { EliteSection } from "@/components/elite-section"
import { Footer } from "@/components/footer"
import { SearchSidebar } from "@/components/search-sidebar"
import { Button } from "@/components/ui/button"
import { Filter } from "lucide-react"
import { InteractiveFighterSilhouette } from "@/components/interactive-fighter-silhouette"
import { TrainingEquipment } from "@/components/training-equipment"

export default function HomePage() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="flex">
        <SearchSidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        <main className="flex-1">
          <div className="lg:hidden sticky top-16 z-30 bg-background/95 backdrop-blur-sm border-b border-border p-4">
            <Button variant="outline" onClick={() => setIsSidebarOpen(true)} className="w-full justify-center">
              <Filter className="h-4 w-4 mr-2" />
              Filtros y Búsqueda
            </Button>
          </div>

          <HeroSection />
          <SportsCategories />
          <InteractiveFighterSilhouette />
          <TrainingEquipment />
          <FeaturedProducts />
          <EliteSection />
        </main>
      </div>

      <Footer />
    </div>
  )
}
