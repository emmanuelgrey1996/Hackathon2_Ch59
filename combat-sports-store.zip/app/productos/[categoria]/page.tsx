"use client"

import { useParams } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ShoppingCart, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"

const productsByCategory: Record<string, { name: string; price: string; description: string; image: string }[]> = {
  headgear: [
    {
      name: "Casco Profesional de Boxeo",
      price: "$89.99",
      description: "Protección completa con acolchado premium y visibilidad óptima",
      image: "/professional-boxing-headgear.jpg",
    },
    {
      name: "Headgear Elite MMA",
      price: "$129.99",
      description: "Diseño ergonómico con protección de mejillas y barbilla",
      image: "/elite-headgear.jpg",
    },
    {
      name: "Casco de Taekwondo",
      price: "$79.99",
      description: "Certificado para competición, ultra ligero",
      image: "/taekwondo-uniform-and-protective-gear.jpg",
    },
  ],
  mouthguard: [
    {
      name: "Bucal Premium Moldeado",
      price: "$24.99",
      description: "Protección dental superior con ajuste personalizado",
      image: "/mouthguard.jpg",
    },
    {
      name: "Bucal de Competición",
      price: "$34.99",
      description: "Máxima protección para competidores profesionales",
      image: "/mouthguard.jpg",
    },
  ],
  "chest-protector": [
    {
      name: "Peto de Competición Taekwondo",
      price: "$149.99",
      description: "Certificado WTF, tecnología de absorción de impacto",
      image: "/chest-protector.jpg",
    },
    {
      name: "Protector de Torso MMA",
      price: "$119.99",
      description: "Protección completa para entrenamiento de sparring",
      image: "/chest-guard.jpg",
    },
  ],
  "chest-guard": [
    {
      name: "Protector de Pecho Reversible",
      price: "$79.99",
      description: "Doble cara rojo/azul para competición",
      image: "/chest-guard.jpg",
    },
  ],
  uniforms: [
    {
      name: "Gi de Karate Profesional",
      price: "$89.99",
      description: "100% algodón, corte tradicional",
      image: "/karate-gi-and-competition-equipment.jpg",
    },
    {
      name: "Dobok de Taekwondo",
      price: "$79.99",
      description: "Cuello negro, certificado para competición",
      image: "/taekwondo-uniform-and-protective-gear.jpg",
    },
    {
      name: "Rashguard MMA",
      price: "$59.99",
      description: "Compresión premium, secado rápido",
      image: "/training-shirt.jpg",
    },
  ],
  gloves: [
    {
      name: "Guantes de Boxeo Pro 16oz",
      price: "$119.99",
      description: "Cuero genuino, acolchado multicapa",
      image: "/professional-boxing-gloves.jpg",
    },
    {
      name: "Guantes de Boxeo Elite 14oz",
      price: "$139.99",
      description: "Diseño ergonómico, máxima protección",
      image: "/professional-boxing-gloves-black-and-gold.jpg",
    },
  ],
  wraps: [
    {
      name: "Vendas Mexicanas 4.5m",
      price: "$14.99",
      description: "Elásticas, con cierre de velcro",
      image: "/hand-wraps.jpg",
    },
    {
      name: "Vendas de Gel",
      price: "$24.99",
      description: "Protección de nudillos con gel integrado",
      image: "/hand-wraps.jpg",
    },
  ],
  "mma-gloves": [
    {
      name: "Guantes MMA 4oz",
      price: "$89.99",
      description: "Cuero sintético premium, agarre superior",
      image: "/mma-gloves.jpg",
    },
    {
      name: "Guantes de Sparring MMA 7oz",
      price: "$99.99",
      description: "Mayor acolchado para entrenamiento seguro",
      image: "/mma-gloves-and-fighting-gear.jpg",
    },
  ],
  "shin-guards": [
    {
      name: "Espinilleras Venom",
      price: "$69.99",
      description: "Diseño anatómico, protección de empeine",
      image: "/modern-boxing-shoes.jpg",
    },
    {
      name: "Espinilleras de Competición",
      price: "$89.99",
      description: "Ultra ligeras, certificadas para torneos",
      image: "/modern-boxing-shoes.jpg",
    },
  ],
  "thigh-protector": [
    {
      name: "Protector de Muslo MMA",
      price: "$49.99",
      description: "Protección contra patadas bajas",
      image: "/mma-gloves-and-fighting-gear.jpg",
    },
  ],
  shoes: [
    {
      name: "Zapatillas de Boxeo Pro",
      price: "$99.99",
      description: "Suela antideslizante, soporte de tobillo",
      image: "/modern-boxing-shoes.jpg",
    },
    {
      name: "Zapatillas de Lucha",
      price: "$89.99",
      description: "Agarre superior, ultra ligeras",
      image: "/modern-boxing-shoes.jpg",
    },
  ],
  "groin-protector": [
    {
      name: "Coquilla Profesional",
      price: "$34.99",
      description: "Protección de acero con acolchado",
      image: "/mma-gloves-and-fighting-gear.jpg",
    },
    {
      name: "Protector Inguinal de Competición",
      price: "$44.99",
      description: "Diseño anatómico, máxima comodidad",
      image: "/mma-gloves-and-fighting-gear.jpg",
    },
  ],
  "groin-guard": [
    {
      name: "Protector Inguinal Femenino",
      price: "$39.99",
      description: "Diseño específico para mujeres",
      image: "/mma-gloves-and-fighting-gear.jpg",
    },
  ],
}

const categoryNames: Record<string, string> = {
  headgear: "Cascos y Protección de Cabeza",
  mouthguard: "Bucales",
  "chest-protector": "Petos de Competición",
  "chest-guard": "Protectores de Pecho",
  uniforms: "Uniformes",
  gloves: "Guantes de Boxeo",
  wraps: "Vendas",
  "mma-gloves": "Guantes MMA",
  "shin-guards": "Espinilleras",
  "thigh-protector": "Protectores de Muslo",
  shoes: "Calzado Deportivo",
  "groin-protector": "Coquillas",
  "groin-guard": "Protectores Inguinales",
}

export default function CategoryPage() {
  const params = useParams()
  const categoria = params.categoria as string

  const products = productsByCategory[categoria] || []
  const categoryName = categoryNames[categoria] || "Productos"

  if (products.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Categoría no encontrada</h1>
          <Link href="/">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al inicio
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-black py-12 border-b border-zinc-800">
        <div className="container mx-auto px-4">
          <Link href="/">
            <Button variant="ghost" className="mb-4 text-zinc-400 hover:text-amber-500">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver
            </Button>
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600">
            {categoryName}
          </h1>
          <p className="text-zinc-400 mt-2">{products.length} productos disponibles</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={product.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-zinc-900 rounded-xl overflow-hidden shadow-xl border border-zinc-800 hover:border-amber-600 transition-all duration-300 hover:shadow-2xl hover:shadow-amber-600/20"
            >
              <div className="aspect-square bg-zinc-800 overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="font-bold text-white text-xl mb-2">{product.name}</h3>
                <p className="text-zinc-400 text-sm mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-3xl font-bold text-amber-500">{product.price}</span>
                  <Button className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Agregar
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  )
}
