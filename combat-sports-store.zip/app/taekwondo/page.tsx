import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"
import Image from "next/image"

export default function TaekwondoPage() {
  const taekwondoProducts = [
    {
      id: 1,
      name: "Dobok Profesional",
      price: "$79.99",
      image: "/taekwondo-uniform-and-protective-gear.jpg",
      category: "Uniformes",
    },
    {
      id: 2,
      name: "Peto Electrónico",
      price: "$199.99",
      image: "/chest-protector.jpg",
      category: "Protección",
    },
    {
      id: 3,
      name: "Casco de Taekwondo",
      price: "$89.99",
      image: "/elite-headgear.jpg",
      category: "Protección",
    },
    {
      id: 4,
      name: "Espinilleras y Empeineras",
      price: "$49.99",
      image: "/taekwondo-shin-guards-white.jpg",
      category: "Protección",
    },
    {
      id: 5,
      name: "Guantes de Taekwondo",
      price: "$39.99",
      image: "/taekwondo-gloves-red.jpg",
      category: "Protección",
    },
    {
      id: 6,
      name: "Protector Bucal",
      price: "$24.99",
      image: "/mouthguard.jpg",
      category: "Protección",
    },
    {
      id: 7,
      name: "Escudo Curvo",
      price: "$89.99",
      image: "/curved-strike-shield.jpg",
      category: "Entrenamiento",
    },
    {
      id: 8,
      name: "Paletas de Pateo",
      price: "$69.99",
      image: "/focus-mitts-pro.jpg",
      category: "Entrenamiento",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center overflow-hidden">
        <Image
          src="/taekwondo-uniform-and-protective-gear.jpg"
          alt="Taekwondo"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
        <div className="relative z-10 text-center px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 elite-text">TAEKWONDO</h1>
          <p className="text-xl md:text-2xl text-zinc-300 max-w-2xl mx-auto">
            Equipo olímpico para maestros del arte marcial
          </p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Productos de Taekwondo</h2>
          <p className="text-zinc-400">Equipo certificado para entrenamiento y competición olímpica</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {taekwondoProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-all duration-300"
            >
              <div className="relative h-64 overflow-hidden bg-zinc-900">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-bold">
                  {product.category}
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{product.name}</h3>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary">{product.price}</span>
                  <Button size="sm" className="gap-2">
                    <ShoppingCart className="h-4 w-4" />
                    Agregar
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  )
}
