// Product Data
const productsData = {
  featured: [
    {
      id: 1,
      name: "Guantes de Boxeo Pro",
      category: "Boxeo",
      price: 89.99,
      image: "public/professional-boxing-gloves-black-and-gold.jpg",
      description: "Guantes profesionales de alta calidad",
    },
    {
      id: 2,
      name: "Uniforme Taekwondo Elite",
      category: "Taekwondo",
      price: 79.99,
      image: "public/taekwondo-uniform-and-protective-gear.jpg",
      description: "Dobok premium para competición",
    },
    {
      id: 3,
      name: "Guantes MMA Competition",
      category: "MMA",
      price: 69.99,
      image: "public/mma-gloves-and-fighting-gear.jpg",
      description: "Guantes profesionales para MMA",
    },
    {
      id: 4,
      name: "Gi de Karate Tradicional",
      category: "Karate",
      price: 74.99,
      image: "public/karate-gi-and-competition-equipment.jpg",
      description: "Gi tradicional de alta calidad",
    },
  ],
  training: [
    {
      id: 5,
      name: "Costal Pesado 150cm",
      category: "bags",
      price: 199.99,
      image: "public/professional-heavy-bag-150cm.jpg",
      description: "Costal profesional de 150cm",
    },
    {
      id: 6,
      name: "Pera de Velocidad Elite",
      category: "bags",
      price: 49.99,
      image: "public/speed-bag-elite.jpg",
      description: "Pera de velocidad profesional",
    },
    {
      id: 7,
      name: "Gobernadora Ajustable",
      category: "bags",
      price: 89.99,
      image: "public/adjustable-double-end-bag.jpg",
      description: "Gobernadora de doble extremo",
    },
    {
      id: 8,
      name: "Jaula Octagonal MMA",
      category: "equipment",
      price: 4999.99,
      image: "public/octagonal-mma-cage.jpg",
      description: "Jaula profesional para MMA",
    },
    {
      id: 9,
      name: "Dummy de Grappling",
      category: "equipment",
      price: 299.99,
      image: "public/grappling-dummy.jpg",
      description: "Dummy para entrenamiento de suelo",
    },
    {
      id: 10,
      name: "Ring de Boxeo Pro",
      category: "equipment",
      price: 3999.99,
      image: "public/professional-boxing-ring.jpg",
      description: "Ring profesional de boxeo",
    },
    {
      id: 11,
      name: "Escudo Curvo Strike",
      category: "accessories",
      price: 79.99,
      image: "public/curved-strike-shield.jpg",
      description: "Escudo curvo para golpes",
    },
    {
      id: 12,
      name: "Manoplas Focus Pro",
      category: "accessories",
      price: 59.99,
      image: "public/focus-mitts-pro.jpg",
      description: "Manoplas profesionales",
    },
  ],
  bodyParts: {
    head: [
      { name: "Casco de Boxeo Pro", price: 89.99 },
      { name: "Protector Bucal Elite", price: 29.99 },
      { name: "Casco Taekwondo", price: 79.99 },
    ],
    torso: [
      { name: "Peto de Competición", price: 119.99 },
      { name: "Protector de Pecho", price: 89.99 },
      { name: "Camiseta de Entrenamiento", price: 39.99 },
    ],
    hands: [
      { name: "Guantes de Boxeo", price: 89.99 },
      { name: "Vendas para Manos", price: 19.99 },
      { name: "Guantes MMA", price: 69.99 },
    ],
    arms: [
      { name: "Coderas Protectoras", price: 49.99 },
      { name: "Mangas de Compresión", price: 29.99 },
    ],
    legs: [
      { name: "Espinilleras Pro", price: 59.99 },
      { name: "Rodilleras Protectoras", price: 44.99 },
      { name: "Musleras de Compresión", price: 34.99 },
    ],
    feet: [
      { name: "Zapatos de Boxeo", price: 99.99 },
      { name: "Protectores de Pie", price: 39.99 },
      { name: "Calcetines de Compresión", price: 24.99 },
    ],
  },
}

// Cart
const cart = []

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  loadFeaturedProducts()
  loadTrainingProducts()
  initializeSilhouette()
  initializeFilters()
  updateCartCount()
})

// Load Featured Products
function loadFeaturedProducts() {
  const container = document.getElementById("featuredProducts")
  if (!container) return

  container.innerHTML = productsData.featured.map((product) => createProductCard(product)).join("")
}

// Load Training Products
function loadTrainingProducts(filter = "all") {
  const container = document.getElementById("trainingProducts")
  if (!container) return

  const filtered = filter === "all" ? productsData.training : productsData.training.filter((p) => p.category === filter)

  container.innerHTML = filtered.map((product) => createProductCard(product)).join("")
}

// Create Product Card
function createProductCard(product) {
  return `
        <div class="product-card">
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-content">
                <div class="product-category">${product.category}</div>
                <h3 class="product-title">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-footer">
                    <span class="product-price">$${product.price}</span>
                    <button class="btn-add-cart" onclick="addToCart(${product.id})">
                        Agregar
                    </button>
                </div>
            </div>
        </div>
    `
}

// Initialize Silhouette
function initializeSilhouette() {
  const bodyParts = document.querySelectorAll(".body-part")
  const panelTitle = document.querySelector(".panel-title")
  const panelSubtitle = document.querySelector(".panel-subtitle")
  const panelProducts = document.getElementById("panelProducts")

  bodyParts.forEach((part) => {
    part.addEventListener("click", () => {
      // Remove active class from all parts
      bodyParts.forEach((p) => p.classList.remove("active"))

      // Add active class to clicked part
      part.classList.add("active")

      // Get part name
      const partName = part.dataset.part
      const products = productsData.bodyParts[partName]

      // Update panel
      const partNames = {
        head: "Cabeza",
        torso: "Torso",
        hands: "Manos",
        arms: "Brazos",
        legs: "Piernas",
        feet: "Pies",
      }

      panelTitle.textContent = `Protección para ${partNames[partName]}`
      panelSubtitle.textContent = `${products.length} productos disponibles`

      panelProducts.innerHTML = products
        .map(
          (product) => `
                <div class="panel-product">
                    <div class="panel-product-name">${product.name}</div>
                    <div class="panel-product-price">$${product.price}</div>
                </div>
            `,
        )
        .join("")
    })
  })
}

// Initialize Filters
function initializeFilters() {
  const filterTabs = document.querySelectorAll(".filter-tab")

  filterTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      // Remove active class from all tabs
      filterTabs.forEach((t) => t.classList.remove("active"))

      // Add active class to clicked tab
      tab.classList.add("active")

      // Filter products
      const filter = tab.dataset.filter
      loadTrainingProducts(filter)
    })
  })
}

// Add to Cart
function addToCart(productId) {
  const allProducts = [...productsData.featured, ...productsData.training]
  const product = allProducts.find((p) => p.id === productId)

  if (product) {
    cart.push(product)
    updateCartCount()
    showNotification(`${product.name} agregado al carrito`)
  }
}

// Update Cart Count
function updateCartCount() {
  const cartCount = document.getElementById("cartCount")
  if (cartCount) {
    cartCount.textContent = cart.length
  }
}

// Show Notification
function showNotification(message) {
  // Simple alert for now - you can enhance this with a custom notification
  console.log("[v0]", message)
}

// Cart Button Click
const cartBtn = document.getElementById("cartBtn")
if (cartBtn) {
  cartBtn.addEventListener("click", () => {
    alert(`Tienes ${cart.length} productos en tu carrito`)
  })
}
